﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniCompiler.Interpretar.Values
{
    public abstract  class InterpreteValue
    {
        public abstract string TU_CADENA();
    }
}
